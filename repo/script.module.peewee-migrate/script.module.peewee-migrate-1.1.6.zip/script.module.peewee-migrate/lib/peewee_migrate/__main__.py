from peewee_migrate.cli import cli


cli()  # noqa
